#!/usr/bin/env python

from function_src import spykingcircus
import sys
import json
import traceback
from hither_sf import ConsoleCapture

def main():
    _configure_kachery()
    kwargs = json.loads('{"sorting_out": "/outputs/sorting_out", "recording_path": "sha1://220b1060b5e3f840bd7a6aa57b1e2e34ef1d1d49/new_recording.json", "detect_threshold": 3}')
    with ConsoleCapture('spykingcircus', show_console=True) as cc:
        print('###### RUNNING: spykingcircus')
        try:
            retval = spykingcircus(**kwargs)
            status = 'finished'
        except:
            traceback.print_exc()
            retval = None
            status = 'error'
                
    runtime_info = cc.runtime_info()
    with open('/run_in_container/result.json', 'w') as f:
        json.dump(dict(retval=retval, status=status, runtime_info=runtime_info), f)
            
def _configure_kachery():
    try:
        import kachery as ka
    except:
        return
    kachery_config = json.loads('{"to": {"url": null, "channel": null, "password": null}, "fr": {"url": "http://kachery.flatironinstitute.org/neuro1", "channel": "public", "password": "public"}, "from_remote_only": false, "to_remote_only": false, "algorithm": "sha1", "verbose": false, "use_hard_links": false}')
    # delete newer use_hard_links key
    kachery_config.pop("use_hard_links", None)
    ka.set_config(**kachery_config)

if __name__ == "__main__":
    try:
        main()
    except:
        sys.stdout.flush()
        sys.stderr.flush()
        raise
        