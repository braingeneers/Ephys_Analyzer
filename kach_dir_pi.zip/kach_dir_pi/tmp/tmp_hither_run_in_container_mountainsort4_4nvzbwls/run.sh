#!/bin/bash
set -e

export NUM_WORKERS=
export MKL_NUM_THREADS=$NUM_WORKERS
export NUMEXPR_NUM_THREADS=$NUM_WORKERS
export OMP_NUM_THREADS=$NUM_WORKERS

export KACHERY_STORAGE_DIR=/kachery-storage PYTHONPATH=/run_in_container/function_src/_local_modules HOME=$HOME
exec python3 /run_in_container/run.py
        